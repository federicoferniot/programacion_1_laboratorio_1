#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "contratacion.h"
#include "pantalla.h"
#include "utn.h"


int informar_ConsultaFacturacion(Contratacion* arrayC,int limite,Pantalla* pantallas, int lenPantallas, char* cuit)
{
    int retorno = -1;
    int i;
    int indexPantalla;
    if(limite > 0 && arrayC != NULL)
    {
        for(i=0; i<limite;i++)
        {
            if(!arrayC[i].isEmpty && !strcmp(arrayC[i].cuit,cuit))
            {
                indexPantalla = pantalla_buscarPorId(pantallas,lenPantallas,arrayC[i].idPantalla);
                printf("\n\nCuit: %s - Unitario: %.2f - Total: %.2f - Dias: %d\n",
                                    arrayC[i].cuit,
                                    pantallas[indexPantalla].precio,
                                    (arrayC[i].dias * pantallas[indexPantalla].precio),
                                    arrayC[i].dias );
            }
        }

        retorno = 0;
    }
    return retorno;
}


int inf_listar_contrataciones(Contratacion* contrataciones, Pantalla* pantallas,int limiteCont, int limitePant)
{
    int retorno = -1;
    int i;
    int auxIndicePantalla;
    if(limiteCont > 0 && contrataciones != NULL)
    {
        retorno = 0;
        for(i=0;i<limiteCont;i++)
        {
            if(!contrataciones[i].isEmpty)
            {
                auxIndicePantalla = pantalla_buscarPorId(pantallas, limitePant, contrataciones[i].idPantalla);
                printf(" - %s - %s - %d - %s\n",pantallas[auxIndicePantalla].nombre,contrataciones[i].archivo, contrataciones[i].dias, contrataciones[i].cuit);
            }
        }
    }
    return retorno;
}


int inf_listarClientes(Contratacion* contrataciones, Pantalla* pantallas,int limiteCont, int limitePant)
{
    int retorno = -1;
    int i;
    int auxIndicePantalla;
    int contadorContrataciones=0;
    char auxCuit[20];
    float acumuladorFacturacion=0;
    contratacion_ordenarPorCuit(contrataciones, limiteCont, 0);
    if(limiteCont > 0 && contrataciones != NULL)
    {
        retorno = 0;
        if(!contrataciones[0].isEmpty)
        {
            contadorContrataciones=1;
            auxIndicePantalla = pantalla_buscarPorId(pantallas, limitePant,contrataciones[0].idPantalla);
            strcpy(auxCuit, contrataciones[0].cuit);
            acumuladorFacturacion += (contrataciones[0].dias*pantallas[auxIndicePantalla].precio);
        }
        for(i=1;i<limiteCont;i++)
        {
            if(!contrataciones[i].isEmpty && !contrataciones[i-1].isEmpty)
            {
                if(!strcmp(contrataciones[i].cuit,contrataciones[i-1].cuit))
                {
                    contadorContrataciones++;
                    strcpy(auxCuit, contrataciones[i].cuit);
                    auxIndicePantalla = pantalla_buscarPorId(pantallas, limitePant,contrataciones[0].idPantalla);
                    acumuladorFacturacion += (contrataciones[0].dias*pantallas[auxIndicePantalla].precio);
                }
                else
                {
                    printf("%s - %d - %g\n", auxCuit, contadorContrataciones, acumuladorFacturacion);
                    contadorContrataciones=1;
                    auxIndicePantalla = pantalla_buscarPorId(pantallas, limitePant,contrataciones[0].idPantalla);
                    acumuladorFacturacion = (contrataciones[i].dias*pantallas[auxIndicePantalla].precio);
                }
            }
            if(i==limiteCont-1)
            {
                printf("%s - %d - %g\n", auxCuit, contadorContrataciones, acumuladorFacturacion);
            }
        }
    }
    return retorno;
}

