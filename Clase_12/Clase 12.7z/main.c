#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "pantalla.h"
#include "contratacion.h"
#include "utn.h"
#include "informes.h"
#define LEN_PANT 100
#define LEN_CONT 1000



int main()
{
    Pantalla pantallas[LEN_PANT];
    Contratacion contrataciones[LEN_CONT];

    int menu;
    int auxiliarId;
    char auxiliarCuit[20];

    contratacion_init(contrataciones, LEN_CONT);
    pantalla_init(pantallas,LEN_PANT);

    pantalla_altaForzada(pantallas,LEN_PANT,"Wilde","Las Flores 50",1,0);
    pantalla_altaForzada(pantallas,LEN_PANT,"Avellaneda","Belgrano 250",1,0);
    pantalla_altaForzada(pantallas,LEN_PANT,"Bernal","Cerrito 300",1,0);
    pantalla_altaForzada(pantallas,LEN_PANT,"Quilmes","Lavalle 450",1,0);
    pantalla_altaForzada(pantallas,LEN_PANT,"Berazategui","Mitre 150",1,0);

    cont_altaForzada(contrataciones,LEN_CONT,pantallas,LEN_PANT,0,"video.avi","20911911915",100);
    cont_altaForzada(contrataciones,LEN_CONT,pantallas,LEN_PANT,0,"video1.avi","20911911915",400);
    cont_altaForzada(contrataciones,LEN_CONT,pantallas,LEN_PANT,0,"video2.avi","30911911915",300);
    cont_altaForzada(contrataciones,LEN_CONT,pantallas,LEN_PANT,2,"video3.avi","30911911915",400);
    cont_altaForzada(contrataciones,LEN_CONT,pantallas,LEN_PANT,2,"video4.avi","40911911915",500);
    cont_altaForzada(contrataciones,LEN_CONT,pantallas,LEN_PANT,2,"video5.avi","40911911915",600);

    inf_listar_contrataciones(contrataciones, pantallas, LEN_CONT, LEN_PANT);
    inf_listarClientes(contrataciones, pantallas, LEN_CONT, LEN_PANT);
    printf("\n");
    inf_listar_contrataciones(contrataciones, pantallas, LEN_CONT, LEN_PANT);

    do
    {
        getValidInt("1.Alta Pantalla\n2.Modificar pantalla\n3.Baja Pantalla\n4.Contratar publicidad\n5.Modificar condiciones de Publicacion\n6.Mostrar Debug\n7.Listar contrataciones\n9.Mostrar Pantallas\n11.Salir\n","\nNo valida\n",&menu,1,11,1);
        switch(menu)
        {
            case 1:
                pantalla_alta(pantallas,LEN_PANT);
                break;
            case 2:
                getValidInt("ID?\n","\nNumero valida\n",&auxiliarId,0,200,2);
                pantalla_modificacion(pantallas,LEN_PANT,auxiliarId);
                break;
            case 3:
                getValidInt("ID?\n","\nNumero valida\n",&auxiliarId,0,200,2);
                pantalla_baja(pantallas,LEN_PANT,auxiliarId);
                break;
            case 4:
                pantalla_mostrar(pantallas,LEN_PANT);
                contratacion_alta(contrataciones, pantallas, LEN_CONT, LEN_PANT);
                break;
            case 5:
                getValidString("Cuit?\n","\nIngrese cuit valido\n", "\nEl maximo es 20\n", auxiliarCuit, 20, 2);
                contratacion_mostrar_por_cuit(contrataciones, LEN_CONT, auxiliarCuit);
                break;
            case 6:
                pantalla_mostrarDebug(pantallas,LEN_PANT);
                break;
            case 7:
                inf_listar_contrataciones(contrataciones, pantallas, LEN_CONT, LEN_PANT);
                break;
            case 9:
                pantalla_mostrar(pantallas,LEN_PANT);
        }

    }while(menu != 11);

    return 0;
}
