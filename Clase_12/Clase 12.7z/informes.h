#ifndef INFORMES_H_INCLUDED
#define INFORMES_H_INCLUDED
#include "pantalla.h"
#include "contratacion.h"

int inf_listar_contrataciones(Contratacion* contrataciones, Pantalla* pantallas,int limiteCont, int limitePant);
int inf_listarClientes(Contratacion* contrataciones, Pantalla* pantallas,int limiteCont, int limitePant);
int inf_cliente_importe_mas_alto(Contratacion* contrataciones, Pantalla* pantallas,int limiteCont, int limitePant);
int informar_ConsultaFacturacion(Contratacion* arrayC,int limite,
              Pantalla* pantallas, int lenPantallas, char* cuit);

#endif // INFORMES_H_INCLUDED
