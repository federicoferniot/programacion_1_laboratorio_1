#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "contratacion.h"
#include "pantalla.h"
#include "utn.h"

static int proximoId();
static int buscarLugarLibre(Contratacion* contrataciones,int limite);


/** \brief
 * \param contrataciones Pantalla*
 * \param limite int
 * \return int
 *
 */
int contratacion_init(Contratacion* contrataciones,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && contrataciones != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            contrataciones[i].isEmpty=1;
        }
    }
    return retorno;
}

int contratacion_mostrar_por_cuit(Contratacion* array,int limite, char cuit[20])
{
    int retorno = -1;
    int i;
    if(limite > 0 && array != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            if(!array[i].isEmpty && !strcmp(array[i].cuit, cuit))
                printf("[RELEASE] - %d - %s - %d\n",array[i].idContratacion, array[i].cuit, array[i].dias);
        }
    }
    return retorno;
}

int contratacion_mostrar(Contratacion* contrataciones,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && contrataciones != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            if(!contrataciones[i].isEmpty)
                printf("[RELEASE] - %d - %s - %d\n",contrataciones[i].idContratacion, contrataciones[i].cuit, contrataciones[i].isEmpty);
        }
    }
    return retorno;
}


int contratacion_alta(Contratacion* contrataciones, Pantalla* pantallas,int limiteCont, int limitePant)
{
    int retorno = -1;
    int i;
    int idPantalla;
    char cuit[20];
    char archivo[30];
    int dias;
    if(limiteCont > 0 && contrataciones != NULL)
    {
        i = buscarLugarLibre(contrataciones,limiteCont);
        if(i >= 0)
        {
            if(!getValidInt("ID?\n", "\nNumero no valido\n", &idPantalla, 0, 999999, 2))
            {
                if(pantalla_buscarPorId(pantallas, limitePant, idPantalla)>=0)
                {
                    if(!getValidString("\nCuit de usuario? ","\nEso no es un cuit","El maximo es 40",cuit,40,2))
                    {
                        if(!getValidString("\nNombre de archivp? ","\nEso no es un nombre de archivo","El maximo es 40",archivo,40,2))
                        {
                            if(!getValidInt("\nDias de publicacion? ","\nEso no es una cantidad de dias",&dias,0,9999999,2))
                            {
                                retorno = 0;
                                strcpy(contrataciones[i].cuit,cuit);
                                strcpy(contrataciones[i].archivo,archivo);
                                contrataciones[i].dias = dias;
                                contrataciones[i].idPantalla = 1;
                                //------------------------------
                                //------------------------------
                                contrataciones[i].idContratacion = proximoId();
                                contrataciones[i].isEmpty = 0;
                            }
                        }
                    }
                    else
                    {
                        retorno = -3;
                    }
                }
                else
                {
                    retorno = -4;
                }
            }
            else
            {
                retorno = -2;
            }
        }
        else
        {
            retorno = -2;
        }

    }
    return retorno;
}

static int buscarLugarLibre(Contratacion* contrataciones,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && contrataciones != NULL)
    {
        for(i=0;i<limite;i++)
        {
            if(contrataciones[i].isEmpty==1)
            {
                retorno = i;
                break;
            }
        }
    }
    return retorno;
}

static int proximoId()
{
    static int proximoId = -1;
    proximoId++;
    return proximoId;
}

int contratacion_ordenarPorCuit(Contratacion* array,int limite, int orden)
{
    int retorno = -1;
    int i;
    int flagSwap;
    Contratacion auxiliarEstructura;

    if(limite > 0 && array != NULL)
    {
        do
        {
            flagSwap = 0;
            for(i=0;i<limite-1;i++)
            {
                if(!array[i].isEmpty && !array[i+1].isEmpty)
                {
                    if((strcmp(array[i].cuit,array[i+1].cuit) > 0 && orden) || (strcmp(array[i].cuit,array[i+1].cuit) < 0 && !orden)) //******
                    {
                        auxiliarEstructura = array[i];
                        array[i] = array[i+1];
                        array[i+1] = auxiliarEstructura;
                        flagSwap = 1;
                    }
                }
            }
        }while(flagSwap);
    }
    return retorno;
}

int cont_altaForzada(Contratacion* arrayC,int limite,
              Pantalla* pantallas, int lenPantallas,
              int idPantalla,char* archivo,char* cuit,int dias)
{
    int retorno = -1;
    int i;
    int posPant;
    if(limite > 0 && arrayC != NULL)
    {
        i = buscarLugarLibre(arrayC,limite);
        if(i >= 0)
        {

            posPant = pantalla_buscarPorId(pantallas,lenPantallas,idPantalla);
            if(posPant>=0)
            {
                arrayC[i].dias = dias;
                strcpy(arrayC[i].cuit,cuit);
                strcpy(arrayC[i].archivo,archivo);
                //TODO
                arrayC[i].idPantalla = idPantalla; // relacion
                arrayC[i].isEmpty=0;
                arrayC[i].idContratacion = proximoId();
            }
        }
        retorno = 0;
    }
    return retorno;
}
