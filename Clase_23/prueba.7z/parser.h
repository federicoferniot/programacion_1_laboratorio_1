int parserEmployee(char* path , ArrayList* pArrayListEmployee);
int parser_guardar(char* path , ArrayList* pArrayListEmployee);
