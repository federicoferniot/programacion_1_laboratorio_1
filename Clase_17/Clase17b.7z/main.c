#include <stdio.h>
#include <stdlib.h>
#include "alumno.h"

void mostrar(Alumno* array[],int cantidad);
void cargar(Alumno** array,int cantidadMaxima,int* cantidadActual);
void guardarTodo(Alumno* array[],int cantidad);

int main()
{

    Alumno* arrayPunteroAlumnos[4000];
    int qtyActualArrayAlumnos = 0;
    int qtyMaximaArrayAlumnos = 4000;

    cargar(arrayPunteroAlumnos,qtyMaximaArrayAlumnos,&qtyActualArrayAlumnos);
    mostrar(arrayPunteroAlumnos,qtyActualArrayAlumnos);

    arrayAlumno_add(arrayPunteroAlumnos, qtyMaximaArrayAlumnos, &qtyActualArrayAlumnos, "2520502", "Carlos", "Pepe", "89489489" , 1.8, -1);

    guardarTodo(arrayPunteroAlumnos,qtyActualArrayAlumnos);
    //modificar(arrayPunteroAlumnos,qtyActualArrayAlumnos);

   // mostrar(arrayPunteroAlumnos,qtyActualArrayAlumnos);
    return 0;
}


void cargar(Alumno** array,int cantidadMaxima,int* cantidadActual)
{
    /*
    int i;
    for(i=0;i<40;i++)
    {
        arrayAlumno_add(array, cantidadMaxima, cantidadActual, "28000555", "JUAN", "PEREZ", "20-28000555-6", i, -1);
    }*/
    int resultado;
    char id[30];
    char nombre[50];
    char apellido[50];
    char cuit[50];
    char altura[30];
    FILE* archivo = fopen("data.txt", "r");
    if(archivo != NULL)
    {
        do
        {
            resultado = fscanf(archivo, "%[^,],%[^,],%[^,],%[^,],%[^\n]\n", id, nombre, apellido, cuit, altura);
            if(resultado==5)
                arrayAlumno_add(array, cantidadMaxima, cantidadActual, cuit, nombre, apellido, cuit , atof(altura), atoi(id));
        }while(!feof(archivo));
        fclose(archivo);
    }
}

void mostrar(Alumno* array[],int cantidad)
{
    int i;
    int id;
    char nombre[50];
    char apellido[50];
    char cuit[50];
    float altura;
    for(i=0;i<cantidad;i++)
    {
        alumno_getId(array[i],&id);
        alumno_getNombre(array[i],nombre);
        alumno_getApellido(array[i],apellido);
        alumno_getCuit(array[i],cuit);
        alumno_getAltura(array[i],&altura);
        printf("\nId: %d -NombreApellido: %s %s, Cuit:%s - Altura:%f",id, nombre, apellido, cuit,altura);
    }
}

void guardarTodo(Alumno* array[],int cantidad)
{
    int i;
    int id;
    char nombre[50];
    char apellido[50];
    char cuit[50];
    float altura;
    FILE* archivo = fopen("data.txt", "w");
    if(archivo !=NULL)
    {
        for(i=0;i<cantidad;i++)
        {
            alumno_getId(array[i],&id);
            alumno_getNombre(array[i],nombre);
            alumno_getApellido(array[i],apellido);
            alumno_getCuit(array[i],cuit);
            alumno_getAltura(array[i],&altura);
            fprintf(archivo,"%d,%s,%s,%s,%f\n",id, nombre, apellido, cuit,altura);
        }
    }
}

void modificar(Alumno* array[],int cantidad)
{
    int i;
    Alumno* auxiliarAlumno;
    for(i=5;i<10;i++)
    {
        auxiliarAlumno = arrayAlumno_getById(array,cantidad,i);
        if(auxiliarAlumno != NULL)
        {
            alumno_setAltura(auxiliarAlumno,88);
        }
    }
}
