#include <stdio.h>
#include <stdlib.h>
#include "ArrayList.h"
#include "destinatario.h"
#include "parser.h"

ArrayList* destinatarioSinBlackList(ArrayList* destinatarios, ArrayList* blackList);
int borrar_duplicados(ArrayList* pArrayA, ArrayList* pArrayB);
ArrayList* depurar(ArrayList* pArrayDestinatarios, ArrayList* pArrayBlackList);
int listar_destinatarios(ArrayList* pArray);

int main()
{
    ArrayList* pArrayDestinatarios;
    ArrayList* pArrayBlackList;
    ArrayList* pArrayDepurado;
    pArrayDestinatarios = al_newArrayList();
    pArrayBlackList = al_newArrayList();
    char seguir='s';
    int opcion=0;
    int indice;

    while(seguir=='s')
    {
        printf("1. Cargar destinatarios\n");
        printf("2. Cargar lista negra\n");
        printf("3. Depurar\n");
        printf("4. Listar\n");
        printf("5.Salir\n");

        scanf("%d",&opcion);

        switch(opcion)
        {
            case 1:
                parserDestinatario("destinatarios.csv", pArrayDestinatarios);
                break;
            case 2:
                parserDestinatario("black_list.csv", pArrayBlackList);
                break;
            case 3:
                pArrayDepurado = depurar(pArrayDestinatarios, pArrayBlackList);
                break;
            case 4:
                //printf("Destinatarios\n");
                //listar_destinatarios(pArrayDestinatarios);
                //printf("BlackList\n");
                //listar_destinatarios(pArrayBlackList);
                printf("Depurado\n");
                listar_destinatarios(pArrayDepurado);
                break;
            case 5:
                seguir = 'n';
                break;
        }
    }
    return 0;
}


int listar_destinatarios(ArrayList* pArray)
{
    int i;
    int retorno = -1;
    EDestinatario* auxDestinatario;
    if(pArray != NULL)
    {
        for(i=0;i<al_len(pArray);i++)
        {
            auxDestinatario = al_get(pArray, i);
            destinatario_mostrar(auxDestinatario);
        }
    }
    else
        printf("NULL\n");
    return 0;
}

ArrayList* depurar(ArrayList* pArrayDestinatarios, ArrayList* pArrayBlackList)
{
    ArrayList* arrayDepurado = NULL;
    ArrayList* auxDestinatarios;
    ArrayList* auxBlackList;
    al_sort(pArrayDestinatarios, destinatario_compareNombreYMail, 1);
    al_sort(pArrayBlackList, destinatario_compareNombreYMail, 1);
    auxDestinatarios = al_clone(pArrayDestinatarios);
    auxBlackList = al_clone(pArrayBlackList);
    borrar_duplicados(pArrayDestinatarios, auxDestinatarios);
    borrar_duplicados(pArrayBlackList, auxBlackList);
    arrayDepurado = destinatarioSinBlackList(auxDestinatarios, auxBlackList);
    return arrayDepurado;
}

int borrar_duplicados(ArrayList* pArrayA, ArrayList* pArrayB)
{
    int i;
    int indice;
    int retorno = -1;
    EDestinatario* destinatarioA;
    EDestinatario* destinatarioB;
    for(i=0;i<(al_len(pArrayA)-1);i++)
    {
        retorno = 0;
        destinatarioA = al_get(pArrayA, i);
        destinatarioB = al_get(pArrayA, i+1);
        if(!destinatario_compareNombreYMail(destinatarioA, destinatarioB))
        {
            indice = al_indexOf(pArrayB, destinatarioA);
            al_remove(pArrayB, indice);
        }
    }
    return retorno;
}

ArrayList* destinatarioSinBlackList(ArrayList* destinatarios, ArrayList* blackList)
{
    ArrayList* depurado;
    depurado = al_newArrayList();
    int i;
    EDestinatario* destinatarioA;
    if(depurado != NULL)
    {
        for(i=0;i<al_len(destinatarios);i++)
        {
            destinatarioA = al_get(destinatarios, i);
            if(!al_containsCompare(blackList, destinatarioA, destinatario_compareNombreYMail))
            {
                al_add(depurado, destinatarioA);
            }
        }
    }
    return depurado;
}
