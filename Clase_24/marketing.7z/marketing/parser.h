int parserDestinatario(char* path , ArrayList* pArrayList);
