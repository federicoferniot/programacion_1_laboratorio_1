#ifndef DESTINATARIO_H_INCLUDED
#define DESTINATARIO_H_INCLUDED
typedef struct
{
    char nombre[60];
    char mail[60];
}EDestinatario;

EDestinatario* destinatario_new();
void destinatario_delete();

int destinatario_setNombre(EDestinatario* this,char* nombre);
int destinatario_getNombre(EDestinatario* this,char* nombre);

int destinatario_setMail(EDestinatario* this,char* mail);
int destinatario_getMail(EDestinatario* this,char* mail);

void destinatario_mostrar(EDestinatario* pDestinatario);
int destinatario_compareNombreYMail(void* pDestinatarioA,void* pDestinatarioB);
int destinatario_compareNombre(void* pDestinatarioA,void* pDestinatarioB);

#endif // DESTINATARIO_H_INCLUDED
