#include <stdio.h>
#include <stdlib.h>
#include "ArrayList.h"
#include "parser.h"
#include "destinatario.h"


int parserDestinatario(char* path , ArrayList* pArrayList)
{
    int retorno =-1;
    char nombre[4000];
    char mail[4000];
    EDestinatario* auxDestinatario;

    FILE* pFile;
    pFile = fopen(path, "r");
    if(pFile != NULL && al_isEmpty(pArrayList))
    {
        retorno =0;
        fscanf(pFile, "%[^,],%[^\n]\n",
                nombre, mail);
        while(!feof(pFile))
        {
            auxDestinatario = destinatario_new();
            destinatario_setNombre(auxDestinatario, nombre);
            destinatario_setMail(auxDestinatario, mail);
            al_add(pArrayList, auxDestinatario);
            fscanf(pFile, "%[^,],%[^\n]\n",
                   nombre, mail);
        }
        fclose(pFile);
    }
    return retorno;
}
