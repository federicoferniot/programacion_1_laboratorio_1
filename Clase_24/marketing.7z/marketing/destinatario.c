#include "destinatario.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

EDestinatario* destinatario_new()
{
    EDestinatario* this;
    this=malloc(sizeof(EDestinatario));
    return this;
}

void destinatario_delete(EDestinatario* this)
{
    free(this);
}

int destinatario_setNombre(EDestinatario* this,char* nombre)
{
    int retorno=-1;
    if(this!=NULL && nombre!=NULL)
    {
        strcpy(this->nombre,nombre);
        retorno=0;
    }
    return retorno;
}

int destinatario_getNombre(EDestinatario* this,char* nombre)
{
    int retorno=-1;
    if(this!=NULL && nombre!=NULL)
    {
        strcpy(nombre,this->nombre);
        retorno=0;
    }
    return retorno;
}

int destinatario_setMail(EDestinatario* this,char* mail)
{
    int retorno=-1;
    if(this!=NULL && mail!=NULL)
    {
        strcpy(this->mail,mail);
        retorno=0;
    }
    return retorno;
}

int destinatario_getMail(EDestinatario* this,char* mail)
{
    int retorno=-1;
    if(this!=NULL && mail!=NULL)
    {
        strcpy(mail,this->mail);
        retorno=0;
    }
    return retorno;
}

void destinatario_mostrar(EDestinatario* pDestinatario)
{
    char nombre[60];
    char mail[60];
    destinatario_getNombre(pDestinatario, nombre);
    destinatario_getMail(pDestinatario, mail);
    printf("Nombre: %s, Mail: %s\n", nombre,mail);
}

int destinatario_compareNombreYMail(void* pDestinatarioA,void* pDestinatarioB)
{
    int retorno;
    char nombreDestinatarioA[64];
    char mailDestinatarioA[64];
    char nombreDestinatarioB[64];
    char mailDestinatarioB[64];
    if(pDestinatarioA!=NULL && pDestinatarioB != NULL)
    {
        destinatario_getNombre(pDestinatarioA,nombreDestinatarioA);
        destinatario_getMail(pDestinatarioA,mailDestinatarioA);
        destinatario_getNombre(pDestinatarioB,nombreDestinatarioB);
        destinatario_getMail(pDestinatarioB,mailDestinatarioB);
        if(strcmp(nombreDestinatarioA, nombreDestinatarioB)<0)
        {
            retorno = -1;
        }
        else if(strcmp(nombreDestinatarioA, nombreDestinatarioB)>0)
        {
            retorno = 1;
        }
        else if(!strcmp(nombreDestinatarioA,nombreDestinatarioB))
        {
            if(strcmp(mailDestinatarioA, mailDestinatarioB)<0)
            {
                retorno = -1;
            }
            else if(strcmp(mailDestinatarioA, mailDestinatarioB)>0)
            {
                retorno = 1;
            }
            else
            {
                retorno = 0;
            }
        }
    }
    return retorno;
}

int destinatario_compareNombre(void* pDestinatarioA,void* pDestinatarioB)
{
    int retorno=0;
    char nombreDestinatarioA[64];
    char nombreDestinatarioB[64];
    if(pDestinatarioA!=NULL && pDestinatarioB != NULL)
    {
        destinatario_getNombre(pDestinatarioA,nombreDestinatarioA);
        destinatario_getNombre(pDestinatarioB,nombreDestinatarioB);
        if(strcmp(nombreDestinatarioA, nombreDestinatarioB)<0)
        {
            retorno = -1;
        }
        else if(strcmp(nombreDestinatarioA, nombreDestinatarioB)>0)
        {
            retorno = 1;
        }
    }
    return retorno;
}
