#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "pantalla.h"
#include "contratacion.h"
#include "utn.h"
#define LEN_PANT 100
#define LEN_CONT 1000

int main()
{
    Pantalla pantallas[LEN_PANT];
    Contratacion contrataciones[LEN_CONT];

    int menu;
    int auxiliarId;
    char auxiliarCuit[20];

    contratacion_init(contrataciones, LEN_CONT);
    pantalla_init(pantallas,LEN_PANT);
    do
    {
        getValidInt("1.Alta Pantalla\n2.Modificar pantalla\n3.Baja Pantalla\n4.Contratar publicidad\n5.Modificar condiciones de Publicacion\n6.Mostrar Debug\n9.Mostrar Pantallas\n11.Salir\n","\nNo valida\n",&menu,1,11,1);
        switch(menu)
        {
            case 1:
                pantalla_alta(pantallas,LEN_PANT);
                break;
            case 2:
                getValidInt("ID?\n","\nNumero valida\n",&auxiliarId,0,200,2);
                pantalla_modificacion(pantallas,LEN_PANT,auxiliarId);
                break;
            case 3:
                getValidInt("ID?\n","\nNumero valida\n",&auxiliarId,0,200,2);
                pantalla_baja(pantallas,LEN_PANT,auxiliarId);
                break;
            case 4:
                pantalla_mostrar(pantallas,LEN_PANT);
                contratacion_alta(contrataciones, pantallas, LEN_CONT, LEN_PANT);
                break;
            case 5:
                getValidString("Cuit?\n","\nIngrese cuit valido\n", "\nEl maximo es 20\n", auxiliarCuit, 20, 2);
                contratacion_mostrar_por_cuit(contrataciones, LEN_CONT, auxiliarCuit);
                break;
            case 6:
                pantalla_mostrarDebug(pantallas,LEN_PANT);
                break;
            case 9:
                pantalla_mostrar(pantallas,LEN_PANT);
        }

    }while(menu != 11);

    return 0;
}
