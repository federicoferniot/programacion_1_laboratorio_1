#ifndef CONTRATACION_H_INCLUDED
#define CONTRATACION_H_INCLUDED
#include "pantalla.h"

typedef struct
{
    char cuit[20];
    int idPantalla;
    int dias;
    char archivo[30];
    int idContratacion;
    int isEmpty;

}Contratacion;

int contratacion_init(Contratacion* array,int limite);
int contratacion_alta(Contratacion* contrataciones, Pantalla* pantallas,int limiteCont, int limitePant);
int contratacion_mostrar_por_cuit(Contratacion* array,int limite, char cuit[20]);

#endif // CONTRATACION_H_INCLUDED


